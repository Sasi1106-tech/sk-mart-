# 🛒 SK Mart – Online Shopping System

SK Mart is a full-stack e-commerce web application developed using Spring Boot, MySQL, HTML, CSS and JavaScript.

The application provides both customer and admin functionalities for managing products, shopping carts, orders, users and inventory.

---

## 🚀 Features

### 👤 Customer Features

* User Registration
* User Login
* Browse Products
* Product Search
* Category-based Product Filtering
* Add Products to Cart
* Update Cart Quantity
* Stock Availability Checking
* Checkout
* Place Orders
* View My Orders
* Order Status Tracking
* Logout

### 👑 Admin Features

* Admin Login
* Admin Dashboard
* View Total Products
* View Total Orders
* View Registered Users
* View Total Sales
* Manage Products
* Add Products
* Edit Products
* Delete Products
* Search Products
* Manage Orders
* Update Order Status
* Monitor Product Stock
* View Recent Orders

---

## 🛠️ Technologies Used

### Frontend

* HTML5
* CSS3
* JavaScript

### Backend

* Java
* Spring Boot
* Spring Data JPA
* REST API

### Database

* MySQL

### Build Tool

* Maven

---

## 📁 Project Structure

```text
sk-mart/
│
├── src/
│   └── main/
│       ├── java/
│       │   └── com/sk-mart/sk-mart/
│       │       ├── controller/
│       │       ├── entity/
│       │       ├── repository/
│       │       └── ...
│       │
│       └── resources/
│           ├── static/
│           │   ├── css/
│           │   ├── js/
│           │   ├── images/
│           │   ├── index.html
│           │   ├── products.html
│           │   ├── cart.html
│           │   ├── checkout.html
│           │   ├── login.html
│           │   ├── register.html
│           │   ├── admin.html
│           │   ├── admin-login.html
│           │   ├── admin-products.html
│           │   └── admin-orders.html
│           │
│           └── application.properties
│
├── pom.xml
├── mvnw
├── mvnw.cmd
└── README.md
```

---

## ⚙️ Requirements

Before running SK Mart, make sure the following are installed:

* Java 17 or later
* MySQL
* VS Code or any Java IDE
* Maven (optional, because Maven Wrapper is included)

---

## 🗄️ Database Setup

Create a MySQL database named:

```sql
CREATE DATABASE lmart;
```

Then configure the database connection in:

```text
src/main/resources/application.properties
```

Example:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/lmart
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

Replace `YOUR_PASSWORD` with your local MySQL password.

**Do not commit your actual database password to GitHub.**

---

## ▶️ Running the Application

Open the SK Mart project in VS Code.

Open the terminal inside the project folder and run:

```powershell
.\mvnw.cmd clean spring-boot:run
```

After the application starts, open the SK Mart website in your browser:

```text
http://localhost:8080/index.html
```

---

## 🔐 Admin Login

Open the admin login page:

```text
http://localhost:8080/admin-login.html
```

Demo admin credentials:

```text
Username: admin
Password: admin123
```

After successful login, the admin will be redirected to the dashboard.

---

## 📊 Admin Dashboard

The admin dashboard provides:

* Total Products
* Total Orders
* Registered Users
* Total Sales
* Recent Orders
* Product Management
* Order Management
* Stock Management

Admin dashboard:

```text
http://localhost:8080/admin.html
```

---

## 🔄 Order Flow

The SK Mart order process works as follows:

```text
Customer
   ↓
Browse Products
   ↓
Search / Category Filter
   ↓
Add to Cart
   ↓
Checkout
   ↓
Place Order
   ↓
Order Saved in MySQL
   ↓
Stock Updated
   ↓
Admin Views Order
   ↓
Admin Updates Order Status
   ↓
Customer Views Updated Status
```

---

## 🔌 Main API Endpoints

### Products

```text
GET    /api/products
POST   /api/products
PUT    /api/products/{id}
DELETE /api/products/{id}
```

### Orders

```text
GET  /api/orders
POST /api/orders
GET  /api/orders/{id}
```

### Authentication

```text
POST /api/auth/register
POST /api/auth/login
```

### Dashboard

```text
GET /api/dashboard/stats
```

---

## 📦 Product Categories

SK Mart supports the following product categories:

* Electronics
* Fashion
* Home
* Accessories

---

## 💾 Data Management

Product, user and order information is stored in the MySQL database.

The application also uses browser localStorage for certain frontend session and shopping-cart information.

---

## 🔒 Security Note

This project is designed as an academic/demo e-commerce application.

The admin login and frontend authentication are implemented for project demonstration purposes.

A production application should use server-side authentication and authorization such as Spring Security with session-based authentication or JWT.

---

## 🎯 Project Objective

The main objective of SK Mart is to develop a simple and functional online shopping platform that demonstrates:

* Full-stack web development
* REST API development
* Database integration
* User authentication
* Product management
* Shopping cart functionality
* Order processing
* Inventory management
* Admin dashboard functionality

---

## ✅ Project Status

**SK Mart is completed and ready for project demonstration.**

The core customer and admin e-commerce functionalities have been implemented and tested successfully.

### Completed Modules

* Customer Registration & Login
* Product Browsing
* Product Search
* Category Filtering
* Shopping Cart
* Checkout & Order Placement
* My Orders
* Stock Management
* Admin Login
* Admin Dashboard
* Product Management
* Order Management
* Order Status Updates
* Sales & User Statistics
* MySQL Database Integration
* REST API Integration

---

## 👨‍💻 Author

**SK Mart – Online Shopping System**

Built as a full-stack e-commerce project using Java, Spring Boot, MySQL, HTML, CSS and JavaScript.
