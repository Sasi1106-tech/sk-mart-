const API_URL = "http://localhost:8080/api/products";
// 🔐 Admin page protection
const adminPages = [
    "admin.html",
    "admin-products.html",
    "admin-orders.html"
];

const currentPage = window.location.pathname.split("/").pop();

if (adminPages.includes(currentPage)) {

    const isAdminLoggedIn =
        localStorage.getItem("luluMartAdminLoggedIn");

    if (isAdminLoggedIn !== "true") {
        window.location.href = "admin-login.html";
    }
}
let cart = JSON.parse(localStorage.getItem("luluMartCart")) || [];

// ===============================
// CART SYSTEM
// ===============================

const cartContainer =
    document.getElementById("cartContainer");

const cartSubtotal =
    document.getElementById("cartSubtotal");

const deliveryCharge =
    document.getElementById("deliveryCharge");

const cartTotal =
    document.getElementById("cartTotal");

const checkoutButton =
    document.getElementById("checkoutButton");


if (cartContainer) {

    displayCart();

}


// ===============================
// DISPLAY CART
// ===============================

function displayCart() {

    let cart =
        JSON.parse(
            localStorage.getItem("luluMartCart")
        ) || [];


    cartContainer.innerHTML = "";


    // Empty cart
    if (cart.length === 0) {

        cartContainer.innerHTML = `

            <div class="empty-cart">

                <div class="empty-cart-icon">
                    🛒
                </div>

                <h2>
                    Your cart is empty
                </h2>

                <p>
                    Looks like you haven't added
                    anything to your cart yet.
                </p>

                <a
                    href="products.html"
                    class="shop-now-btn">

                    Shop Now 🛍️

                </a>

            </div>

        `;

        cartSubtotal.innerText = "₹0";
        deliveryCharge.innerText = "₹0";
        cartTotal.innerText = "₹0";

        checkoutButton.disabled = true;

        return;
    }


    checkoutButton.disabled = false;


    let subtotal = 0;


    // ===============================
    // CART PRODUCTS
    // ===============================

    cart.forEach((product, index) => {

        const itemTotal =
            product.price * product.quantity;


        subtotal += itemTotal;


        cartContainer.innerHTML += `

            <div class="cart-product">

                <div class="cart-product-image">

                    ${
                        product.imageUrl
                        ?
                        `<img
                            src="${product.imageUrl}"
                            alt="${product.name}"
                        >`
                        :
                        "🛍️"
                    }

                </div>


                <div class="cart-product-details">

                    <h3>
                        ${product.name}
                    </h3>

                    <p class="cart-price">
                        ₹${product.price.toLocaleString()}
                    </p>


                    <div class="quantity-section">

                        <span>
                            Quantity:
                        </span>


                        <div class="quantity-controls">

                            <button
                                onclick="decreaseQuantity(${index})">

                                −

                            </button>


                            <span>
                                ${product.quantity}
                            </span>


                            <button
                                onclick="increaseQuantity(${index})">

                                +

                            </button>

                        </div>

                    </div>

                </div>


                <div class="cart-product-total">

                    <strong>
                        ₹${itemTotal.toLocaleString()}
                    </strong>


                    <button
                        class="remove-btn"
                        onclick="removeItem(${index})">

                        🗑️ Remove

                    </button>

                </div>

            </div>

        `;

    });


    // ===============================
    // DELIVERY
    // ===============================

    let delivery = 0;

    if (subtotal > 0 && subtotal < 500) {

        delivery = 40;

    }


    const total =
        subtotal + delivery;


    // ===============================
    // UPDATE SUMMARY
    // ===============================

    cartSubtotal.innerText =
        "₹" + subtotal.toLocaleString();


    deliveryCharge.innerText =
        delivery === 0
        ? "FREE"
        : "₹" + delivery.toLocaleString();


    cartTotal.innerText =
        "₹" + total.toLocaleString();

}


// ===============================
// INCREASE QUANTITY
// ===============================

function increaseQuantity(index) {

    let cart =
        JSON.parse(
            localStorage.getItem("luluMartCart")
        ) || [];


    cart[index].quantity++;


    localStorage.setItem(
        "luluMartCart",
        JSON.stringify(cart)
    );


    displayCart();

}


// ===============================
// DECREASE QUANTITY
// ===============================

function decreaseQuantity(index) {

    let cart =
        JSON.parse(
            localStorage.getItem("luluMartCart")
        ) || [];


    if (cart[index].quantity > 1) {

        cart[index].quantity--;

    } else {

        cart.splice(index, 1);

    }


    localStorage.setItem(
        "luluMartCart",
        JSON.stringify(cart)
    );


    displayCart();

}


// ===============================
// REMOVE PRODUCT
// ===============================

function removeItem(index) {

    let cart =
        JSON.parse(
            localStorage.getItem("luluMartCart")
        ) || [];


    cart.splice(index, 1);


    localStorage.setItem(
        "luluMartCart",
        JSON.stringify(cart)
    );


    displayCart();

}


// ===============================
// CHECKOUT
// ===============================

function goToCheckout() {

    const cart =
        JSON.parse(
            localStorage.getItem("luluMartCart")
        ) || [];


    if (cart.length === 0) {

        alert(
            "Your cart is empty! 🛒"
        );

        return;

    }


    window.location.href =
        "checkout.html";

}





// ===============================
// REGISTER SYSTEM - BACKEND API
// ===============================

const registerForm = document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const name =
            document.getElementById("registerName").value.trim();

        const email =
            document.getElementById("registerEmail").value.trim();

        const password =
            document.getElementById("registerPassword").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {
            alert("Passwords do not match! ❌");
            return;
        }

        try {

            const response = await fetch("/api/auth/register", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    name: name,
                    email: email,
                    password: password
                })

            });

            const data = await response.json();

            if (data.success) {

                alert("Account created successfully! 🎉");

                window.location.href = "login.html";

            } else {

                alert(data.message || "Registration failed! ❌");

            }

        } catch (error) {

            console.error("Registration error:", error);

            alert("Server connection failed! ❌");

        }

    });
}



// ===============================
// LOGIN SYSTEM - BACKEND API
// ===============================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function(event) {

        event.preventDefault();

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;

        try {

            const response = await fetch("/api/auth/login", {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    email: email,
                    password: password
                })

            });

            const data = await response.json();

            if (data.success) {

                // IMPORTANT:
                // Never save the password in localStorage.
                const user = {
                    id: data.userId,
                    name: data.name,
                    email: data.email
                };

                localStorage.setItem(
                    "luluMartUser",
                    JSON.stringify(user)
                );

                localStorage.setItem(
                    "luluMartLoggedIn",
                    "true"
                );

                alert("Login successful! 🎉");

                window.location.href = "index.html";

            } else {

                alert(
                    data.message ||
                    "Invalid email or password! ❌"
                );

            }

        } catch (error) {

            console.error("Login error:", error);

            alert("Server connection failed! ❌");

        }

    });
}



// ===============================
// ACCOUNT / LOGOUT SYSTEM
// ===============================

function updateAuthUI() {

    const loginLink =
        document.querySelector('a[href="login.html"]');

    const loggedIn =
        localStorage.getItem("luluMartLoggedIn");

    const userData =
        localStorage.getItem("luluMartUser");

    if (!loginLink) {
        return;
    }

    if (loggedIn === "true" && userData) {

        let user;

        try {

            user = JSON.parse(userData);

        } catch (error) {

            console.error("Invalid user data");

            localStorage.removeItem("luluMartUser");
            localStorage.removeItem("luluMartLoggedIn");

            return;
        }


        const accountContainer =
            document.createElement("span");

        accountContainer.style.marginLeft = "15px";

        accountContainer.innerHTML = `
            <span style="margin-right: 12px;">
                👋 Hi, ${user.name}
            </span>

            

            <a href="#"
               id="logoutBtn">
                🚪 Logout
            </a>
        `;


        loginLink.replaceWith(accountContainer);


        const logoutBtn =
            document.getElementById("logoutBtn");

        if (logoutBtn) {

            logoutBtn.addEventListener(
                "click",
                function(event) {

                    event.preventDefault();

                    localStorage.removeItem("luluMartUser");
                    localStorage.removeItem("luluMartLoggedIn");

                    alert("Logged out successfully! 👋");

                    window.location.href = "login.html";

                }
            );

        }

    }

}



// ===============================
// RUN AFTER PAGE LOAD
// ===============================

document.addEventListener(
    "DOMContentLoaded",
    updateAuthUI
);





// ===============================
// CHECKOUT SYSTEM
// ===============================

const checkoutForm =
    document.getElementById("checkoutForm");

const checkoutItems =
    document.getElementById("checkoutItems");

const checkoutTotal =
    document.getElementById("checkoutTotal");


if (checkoutItems) {

    displayCheckout();

}


function displayCheckout() {

    checkoutItems.innerHTML = "";

    let total = 0;


    if (cart.length === 0) {

        checkoutItems.innerHTML = `
            <p>
                Your cart is empty.
            </p>
        `;

        checkoutTotal.innerText = "Total: ₹0";

        return;
    }


    cart.forEach((product) => {

        const itemTotal =
            product.price * product.quantity;

        total += itemTotal;


        checkoutItems.innerHTML += `

            <div class="checkout-item">

                <div>

                    <strong>
                        ${product.name}
                    </strong>

                    <p>
                        Quantity:
                        ${product.quantity}
                    </p>

                </div>

                <strong>
                    ₹${itemTotal.toLocaleString()}
                </strong>

            </div>

        `;

    });


    checkoutTotal.innerText =
        "Total: ₹" + total.toLocaleString();

}


// ===============================
// PLACE ORDER
// ===============================


// ===============================
// PLACE ORDER - SPRING BOOT + MYSQL
// ===============================

if (checkoutForm) {

    checkoutForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();

            // Check cart
            if (cart.length === 0) {

                alert("Your cart is empty! 🛒");

                return;
            }

            // Get customer details
            const name =
                document.getElementById("customerName").value.trim();

            const phone =
                document.getElementById("customerPhone").value.trim();

            const address =
                document.getElementById("customerAddress").value.trim();

            const city =
                document.getElementById("customerCity").value.trim();

            const pincode =
                document.getElementById("customerPincode").value.trim();

            const paymentElement =
                document.querySelector(
                    'input[name="payment"]:checked'
                );

            if (!paymentElement) {

                alert("Please select a payment method! ❌");

                return;
            }

            const payment = paymentElement.value;

            // Calculate total
            let total = 0;

            cart.forEach((product) => {

                total +=
                    product.price *
                    product.quantity;

            });

            // Generate Order ID
            const orderId =
                "LM" + Date.now();

            // ===============================
            // ORDER DATA FOR BACKEND
            // ===============================
const orderData = {
    orderId: orderId,
    customerName: name,
    phone: phone,
    address: address,
    city: city,
    pincode: pincode,
    payment: payment,
    total: total,
    products: JSON.stringify(cart)
};
            try {

                // Send order to Spring Boot
                const response = await fetch(
                    "http://localhost:8080/api/orders",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body:
                            JSON.stringify(orderData)
                    }
                );

                if (!response.ok) {

    const errorText = await response.text();

    throw new Error(
        errorText || "Failed to place order"
    );

}

                const savedOrder =
                    await response.json();

                console.log(
                    "Order saved in MySQL:",
                    savedOrder
                );

                // ===============================
                // SAVE ORDER DETAILS LOCALLY
                // FOR ORDER SUCCESS PAGE
                // ===============================

                const completeOrder = {

                    ...savedOrder,

                    products: cart

                };

                localStorage.setItem(
                    "luluMartOrder",
                    JSON.stringify(completeOrder)
                );

                // Save to My Orders also
                let orders =
                    JSON.parse(
                        localStorage.getItem(
                            "luluMartOrders"
                        )
                    ) || [];

                orders.push(completeOrder);

                localStorage.setItem(
                    "luluMartOrders",
                    JSON.stringify(orders)
                );

                // Clear cart
                localStorage.removeItem(
                    "luluMartCart"
                );

                alert(
                    "Order placed successfully! 🎉"
                );

                // Go to success page
                window.location.href =
                    "order-success.html";

            } catch (error) {

                console.error(
                    "Place order error:",
                    error
                );

               alert(
    "❌ Order cannot be placed\n\n" +
    error.message
);

            }

        }
    );

}







// ===============================
// ORDER SUCCESS PAGE
// ===============================

const orderDetails = document.getElementById("orderDetails");

if (orderDetails) {

    const orders =
        JSON.parse(
            localStorage.getItem("luluMartOrders")
        ) || [];

    console.log("Orders found:", orders);

    if (orders.length > 0) {

        const savedOrder =
            orders[orders.length - 1];

        console.log("Latest order:", savedOrder);

        let productsHTML = "";

        savedOrder.products.forEach(product => {

            const itemTotal =
                product.price * product.quantity;

            productsHTML += `

                <div class="order-product">

                    <span>
                        ${product.name}
                        × ${product.quantity}
                    </span>

                    <strong>
                        ₹${itemTotal.toLocaleString()}
                    </strong>

                </div>

            `;
        });

        orderDetails.innerHTML = `

            <div class="order-info">

                <h3>
                    Order Details
                </h3>

                <p>
                    <strong>Order ID:</strong>
                    ${savedOrder.orderId}
                </p>

                <p>
                    <strong>Name:</strong>
                    ${savedOrder.customerName}
                </p>

                <p>
                    <strong>Phone:</strong>
                    ${savedOrder.phone}
                </p>

                <p>
                    <strong>Address:</strong>
                    ${savedOrder.address},
                    ${savedOrder.city} -
                    ${savedOrder.pincode}
                </p>

                <p>
                    <strong>Payment:</strong>
                    ${savedOrder.payment}
                </p>

                <h3>
                    Products
                </h3>

                ${productsHTML}

                <h2>
                    Total:
                    ₹${savedOrder.total.toLocaleString()}
                </h2>

                <p>
                    <strong>Order Date:</strong>
                   ${
                        savedOrder.orderDate
                            ? new Date(savedOrder.orderDate).toLocaleString()
                            : "N/A"
                    }
                </p>

            </div>

        
    `;

    } else {

        orderDetails.innerHTML = `

            <p>
                No recent order found.
            </p>

        `;

    }
}



// ===============================
// MY ORDERS - BACKEND + MYSQL
// ===============================

const ordersContainer =
    document.getElementById("ordersContainer");

if (ordersContainer) {
    loadMyOrders();
}

async function loadMyOrders() {

    try {

        const response = await fetch(
            "http://localhost:8080/api/orders"
        );

        if (!response.ok) {
            throw new Error("Failed to load orders");
        }

        const orders = await response.json();

        const userData = localStorage.getItem("luluMartUser");

if (!userData) {
    ordersContainer.innerHTML = `
        <div class="no-orders">
            <h2>Please Login 🔐</h2>
            <p>Login to view your orders.</p>
            <br>
            <a href="login.html" class="shop-btn">
                Login Now
            </a>
        </div>
    `;
    return;
}

const currentUser = JSON.parse(userData);

const myOrders = orders.filter(order =>
    order.customerName &&
    currentUser.name &&
    order.customerName.toLowerCase().trim() ===
    currentUser.name.toLowerCase().trim()
);

        console.log("Orders from MySQL:", orders);
        

        if (myOrders.length === 0) {

            ordersContainer.innerHTML = `
                <div class="no-orders">

                    <h2>
                        No Orders Yet 😔
                    </h2>

                    <p>
                        You haven't placed any orders.
                    </p>

                    <br>

                    <a
                        href="products.html"
                        class="shop-btn">

                        Start Shopping 🛍️

                    </a>

                </div>
            `;

            return;
        }

        ordersContainer.innerHTML = "";

        myOrders.reverse().forEach((order) => {

            ordersContainer.innerHTML += `

                <div class="order-card">

                    <div class="order-header">

                        <span class="order-id">
                            Order ID:
                            ${order.orderId}
                        </span>

                        <span class="order-status">
                            ✓ Order Placed
                        </span>

                    </div>

                    <div class="order-info">

                        <p>
                            <strong>Customer:</strong>
                            ${order.customerName || "N/A"}
                        </p>

                        <p>
                            <strong>Phone:</strong>
                            ${order.phone || "N/A"}
                        </p>

                        <p>
                            <strong>Address:</strong>
                            ${order.address || "N/A"},
                            ${order.city || ""}
                            -
                            ${order.pincode || ""}
                        </p>

                        <p>
                            <strong>Payment:</strong>
                            ${order.payment || "N/A"}
                        </p>

                        <p>
    <strong>Status:</strong>

    <span class="customer-order-status status-${(
        order.status || "PLACED"
    ).toLowerCase()}">

        ${order.status || "PLACED"}

    </span>
</p>

<div class="order-tracking">

    <div class="tracking-step active">
        <div class="tracking-icon">✓</div>
        <div class="tracking-text">
            <strong>Order Placed</strong>
            <small>Order confirmed</small>
        </div>
    </div>


    <div class="tracking-line
        ${
            ["PACKED", "SHIPPED", "DELIVERED"]
                .includes((order.status || "").toUpperCase())
            ? "active"
            : ""
        }">
    </div>


    <div class="tracking-step
        ${
            ["PACKED", "SHIPPED", "DELIVERED"]
                .includes((order.status || "").toUpperCase())
            ? "active"
            : ""
        }">

        <div class="tracking-icon">
            ${
                ["PACKED", "SHIPPED", "DELIVERED"]
                    .includes((order.status || "").toUpperCase())
                ? "✓"
                : "2"
            }
        </div>

        <div class="tracking-text">
            <strong>Order Packed</strong>
            <small>Order packed</small>
        </div>

    </div>


    <div class="tracking-line
        ${
            ["SHIPPED", "DELIVERED"]
                .includes((order.status || "").toUpperCase())
            ? "active"
            : ""
        }">
    </div>


    <div class="tracking-step
        ${
            ["SHIPPED", "DELIVERED"]
                .includes((order.status || "").toUpperCase())
            ? "active"
            : ""
        }">

        <div class="tracking-icon">
            ${
                ["SHIPPED", "DELIVERED"]
                    .includes((order.status || "").toUpperCase())
                ? "✓"
                : "3"
            }
        </div>

        <div class="tracking-text">
            <strong>Order Shipped</strong>
            <small>Order on the way</small>
        </div>

    </div>


    <div class="tracking-line
        ${
            order.status === "DELIVERED"
            ? "active"
            : ""
        }">
    </div>


    <div class="tracking-step
        ${
            order.status === "DELIVERED"
            ? "active"
            : ""
        }">

        <div class="tracking-icon">
            ${
                order.status === "DELIVERED"
                ? "✓"
                : "4"
            }
        </div>

        <div class="tracking-text">
            <strong>Delivered</strong>
            <small>
                ${
                    order.status === "DELIVERED"
                    ? "Order delivered"
                    : "Waiting for delivery"
                }
            </small>
        </div>

    </div>

</div>

                        <p>
                            <strong>Date:</strong>
                            ${order.orderDate
                                ? new Date(order.orderDate).toLocaleString()
                                : "N/A"}
                        </p>

                    </div>

                    <div class="order-total">

                        Total:
                        ₹${Number(order.total).toLocaleString()}

                    </div>
                    <button
    class="view-order-btn"
    onclick="viewCustomerOrder(${order.id})">

    👁️ View Order

</button>

                </div>

            `;

        });

    } catch (error) {

        console.error(
            "Load orders error:",
            error
        );

        ordersContainer.innerHTML = `

            <div class="no-orders">

                <h2>
                    Unable to load orders ❌
                </h2>

                <p>
                    Please make sure Spring Boot is running.
                </p>

            </div>

        `;

    }

}





// ===============================
// ADMIN DASHBOARD - LIVE DATABASE
// ===============================

const totalProductsElement =
    document.getElementById("totalProducts");

const totalOrdersElement =
    document.getElementById("totalOrders");

const totalUsersElement =
    document.getElementById("totalUsers");

const totalSalesElement =
    document.getElementById("totalSales");


if (totalProductsElement) {

    loadDashboardStats();

}

// ===============================
// LOAD DASHBOARD STATS
// ===============================

async function loadDashboardStats() {

    try {

        const response = await fetch(
            "http://localhost:8080/api/dashboard/stats"
        );

        if (!response.ok) {

            throw new Error(
                "Failed to load dashboard stats"
            );

        }

        const stats = await response.json();

        console.log("Dashboard Stats:", stats);

        // Total Products
        if (totalProductsElement) {

            totalProductsElement.innerText =
                stats.totalProducts;

        }

        // Total Orders
        if (totalOrdersElement) {

            totalOrdersElement.innerText =
                stats.totalOrders;

        }

        // Total Sales
        if (totalSalesElement) {

            totalSalesElement.innerText =
                "₹" +
                Number(stats.totalSales).toLocaleString();

        }

        // Total Users
 if (totalUsersElement) {

    totalUsersElement.innerText =
        stats.totalUsers;

}

    } catch (error) {

        console.error(
            "Dashboard stats error:",
            error
        );

    }

}





// ===============================
// ADMIN DASHBOARD - RECENT ORDERS
// ===============================

const recentOrdersBody =
    document.getElementById("recentOrdersBody");

if (recentOrdersBody) {
    loadRecentOrders();
}

async function loadRecentOrders() {

    try {

        const response = await fetch(
            "http://localhost:8080/api/orders"
        );

        console.log("Orders API status:", response.status);

        if (!response.ok) {
            throw new Error("Failed to load orders");
        }

        const orders = await response.json();

        console.log("Recent Orders:", orders);

        if (!orders || orders.length === 0) {

            recentOrdersBody.innerHTML = `
                <tr>
                    <td colspan="6">
                        No orders found 😔
                    </td>
                </tr>
            `;

            return;
        }

        orders.sort((a, b) =>
            new Date(b.orderDate) -
            new Date(a.orderDate)
        );

        const recentOrders = orders.slice(0, 5);

        recentOrdersBody.innerHTML = "";

        recentOrders.forEach(order => {

            const status =
                (order.status || "PLACED").toUpperCase();

            recentOrdersBody.innerHTML += `

                <tr>

                    <td>
                        ${order.orderId}
                    </td>

                    <td>
                        ${order.customerName || "N/A"}
                    </td>

                    <td>
                        ₹${Number(order.total).toLocaleString()}
                    </td>

                    <td>
                        ${order.payment || "N/A"}
                    </td>

                    <td>
                        <span class="customer-order-status status-${status.toLowerCase()}">
                            ${status}
                        </span>
                    </td>

                    <td>
                        ${
                            order.orderDate
                            ? new Date(order.orderDate).toLocaleString()
                            : "N/A"
                        }
                    </td>

                </tr>

            `;
        });

    } catch (error) {

        console.error(
            "Recent orders error:",
            error
        );

        recentOrdersBody.innerHTML = `
            <tr>
                <td colspan="6">
                    Unable to load orders ❌
                </td>
            </tr>
        `;
    }
}


// ===============================
// ADMIN LOGOUT
// ===============================

function adminLogout() {

    localStorage.removeItem(
        "luluMartAdminLoggedIn"
    );

    alert(
        "Admin logged out successfully!"
    );

    window.location.href =
        "index.html";
}



// ===============================
// ADMIN PRODUCT MANAGEMENT
// BACKEND + MYSQL CRUD
// ===============================

const productForm =
    document.getElementById("productForm");

const adminProductList =
    document.getElementById("adminProductList");

const adminProductSearch =
    document.getElementById("adminProductSearch");



// ===============================
// LOAD PRODUCTS
// ===============================

if (adminProductList) {
    loadAdminProducts();
}


async function loadAdminProducts(searchText = "") {

    try {

        const response =
            await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Failed to load products");
        }

        const products =
            await response.json();

        displayAdminProducts(
            products,
            searchText
        );

    } catch (error) {

        console.error(
            "Error loading products:",
            error
        );

        adminProductList.innerHTML = `
            <tr>
                <td colspan="6">
                    Unable to load products ❌
                </td>
            </tr>
        `;
    }
}


// ===============================
// DISPLAY PRODUCTS
// ===============================

function displayAdminProducts(
    products,
    searchText = ""
) {

    adminProductList.innerHTML = "";

    const filteredProducts =
        products.filter(product =>
            product.name
                .toLowerCase()
                .includes(
                    searchText.toLowerCase()
                )
        );


    if (filteredProducts.length === 0) {

        adminProductList.innerHTML = `
            <tr>
                <td colspan="6">
                    No products found 😔
                </td>
            </tr>
        `;

        return;
    }


    filteredProducts.forEach(product => {

        adminProductList.innerHTML += `

            <tr>

                <td>
                    ${product.id}
                </td>

                <td>
                    ${product.name}
                </td>
<td>
    ${product.category || "-"}
</td>

                <td>
                    ₹${product.price.toLocaleString()}
                </td>

                <td>
                    ${product.quantity}
                </td>

                <td>

                    <button
                        class="edit-btn"
                        onclick="editProduct(${product.id})">

                        Edit ✏️

                    </button>

                    <button
                        class="delete-btn"
                        onclick="deleteProduct(${product.id})">

                        Delete 🗑️

                    </button>

                </td>

            </tr>

        `;

    });
}


// ===============================
// ADD / UPDATE PRODUCT
// ===============================

if (productForm) {

    productForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const name =
                document.getElementById(
                    "productName"
                ).value.trim();


            const price =
                Number(
                    document.getElementById(
                        "productPrice"
                    ).value
                );


            const quantity =
                Number(
                    document.getElementById(
                        "productStock"
                    ).value
                );


            const editId =
                document.getElementById(
                    "editProductId"
                ).value;


           const category =
    document.getElementById("productCategory").value;

const imageUrl =
    document.getElementById("productImageUrl").value.trim();

const productData = {

    name: name,

    price: price,

    quantity: quantity,

    category: category,

    imageUrl: imageUrl

};


            try {

                let response;


                // ===============================
                // UPDATE
                // ===============================

                if (editId) {

                    response =
                        await fetch(
                            `${API_URL}/${editId}`,
                            {
                                method: "PUT",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify(
                                        productData
                                    )
                            }
                        );


                    if (!response.ok) {
                        throw new Error(
                            "Failed to update product"
                        );
                    }


                    alert(
                        "Product updated successfully! ✅"
                    );

                }


                // ===============================
                // ADD
                // ===============================

                else {

                    response =
                        await fetch(
                            API_URL,
                            {
                                method: "POST",

                                headers: {
                                    "Content-Type":
                                        "application/json"
                                },

                                body:
                                    JSON.stringify(
                                        productData
                                    )
                            }
                        );


                    if (!response.ok) {
                        throw new Error(
                            "Failed to add product"
                        );
                    }


                    alert(
                        "Product added successfully! 🎉"
                    );

                }


                // Clear form

                productForm.reset();


                document.getElementById(
                    "editProductId"
                ).value = "";


                // Reload from MySQL

              loadAdminProducts();

            } catch (error) {

                console.error(
                    "Product save error:",
                    error
                );

                alert(
                    "Something went wrong! ❌"
                );

            }

        }
    );

}


// ===============================
// EDIT PRODUCT
// ===============================

async function editProduct(id) {

    try {

        const response =
            await fetch(
                `${API_URL}/${id}`
            );


        if (!response.ok) {
            throw new Error(
                "Product not found"
            );
        }


        const product =
            await response.json();


        document.getElementById(
            "productName"
        ).value =
            product.name;


        document.getElementById(
            "productPrice"
        ).value =
            product.price;


        document.getElementById(
            "productStock"
        ).value =
            product.quantity;

                    document.getElementById("productCategory").value =
            product.category || "";

        document.getElementById("productImageUrl").value =
            product.imageUrl || "";


        document.getElementById(
            "editProductId"
        ).value =
            product.id;


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });


        document.querySelector(
            ".product-form-card h2"
        ).innerText =
            "Edit Product ✏️";

            document.querySelector(
    "#productForm button[type='submit']"
).innerText =
    "Update Product ✏️";

    } catch (error) {

        console.error(
            "Edit product error:",
            error
        );

        alert(
            "Unable to load product ❌"
        );

    }

}


// ===============================
// DELETE PRODUCT
// ===============================

async function deleteProduct(id) {

    const confirmDelete = confirm(
        "Are you sure you want to delete this product?"
    );

    if (!confirmDelete) {
        return;
    }

    try {

        const response = await fetch(
            `${API_URL}/${id}`,
            {
                method: "DELETE"
            }
        );

        if (!response.ok) {
            throw new Error("Failed to delete product");
        }
alert("Product deleted successfully! 🗑️");

loadAdminProducts();
    } catch (error) {

        console.error("Delete product error:", error);

        alert("Unable to delete product ❌");
    }
}

// ===============================
// SEARCH PRODUCTS
// ===============================

if (adminProductSearch) {

    adminProductSearch.addEventListener(
        "input",
        function() {

            loadAdminProducts(
                this.value
            );

        }
    );

}




// ===============================
// CUSTOMER PRODUCT DISPLAY
// ===============================

const productContainer =
    document.getElementById("productContainer");

const searchInput =
    document.getElementById("searchInput");


if (productContainer) {

    displayCustomerProducts();

}



async function displayCustomerProducts(searchText = "") {

    try {

        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Failed to fetch products");
        }

        const products = await response.json();

        productContainer.innerHTML = "";


        // ===============================
        // GET CATEGORY FROM URL
        // Example:
        // products.html?category=Electronics
        // ===============================

        const urlParams =
            new URLSearchParams(window.location.search);

        const selectedCategory =
            urlParams.get("category");


        // ===============================
        // SEARCH + CATEGORY FILTER
        // ===============================

        const filteredProducts = products.filter(product => {

            const matchesSearch =
                product.name
                    .toLowerCase()
                    .includes(searchText.toLowerCase());

            const matchesCategory =
                !selectedCategory ||
                (product.category || "").toLowerCase() ===
                selectedCategory.toLowerCase();

            return matchesSearch && matchesCategory;

        });


        // ===============================
        // NO PRODUCTS
        // ===============================

        if (filteredProducts.length === 0) {

            productContainer.innerHTML = `
                <div class="no-orders">

                    <h2>
                        No Products Found 😔
                    </h2>

                    <p>
                        ${
                            selectedCategory
                            ? `No products found in ${selectedCategory}.`
                            : "Try another search."
                        }
                    </p>

                </div>
            `;

            return;
        }


        // ===============================
        // DISPLAY PRODUCTS
        // ===============================

        filteredProducts.forEach(product => {

            productContainer.innerHTML += `

                <div class="product-card">

                    <div class="product-image">

                        ${
                            product.imageUrl
                            ?
                            `<img
                                src="${product.imageUrl}"
                                alt="${product.name}"
                                width="180"
                                height="150"
                                style="
                                    width: 180px;
                                    height: 150px;
                                    max-width: 180px;
                                    max-height: 150px;
                                    object-fit: contain;
                                    display: block;
                                    margin: auto;
                                "
                            >`
                            :
                            "🛍️"
                        }

                    </div>


                    <h3>
                        ${product.name}
                    </h3>


                    <p class="price">
                        ₹${Number(product.price).toLocaleString()}
                    </p>


                    <p>
                        Stock:
                        ${product.quantity}
                    </p>


                    <button
                        onclick="addProductToCart(${product.id})"
                        ${product.quantity <= 0 ? "disabled" : ""}>

                        ${
                            product.quantity <= 0
                            ? "Out of Stock"
                            : "Add to Cart 🛒"
                        }

                    </button>

                </div>

            `;

        });


    } catch (error) {

        console.error(
            "Error loading products:",
            error
        );

        productContainer.innerHTML = `
            <div class="no-orders">

                <h2>
                    Unable to load products ❌
                </h2>

                <p>
                    Please make sure the backend is running.
                </p>

            </div>
        `;

    }

}


// ===============================
// SEARCH
// ===============================

if (searchInput) {

    searchInput.addEventListener(
        "input",
        function() {

            displayCustomerProducts(
                this.value
            );

        }
    );

}





// ===============================
// ADD PRODUCT TO CART
// ===============================

async function addProductToCart(id) {

    try {

        // Get ALL products from backend
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Unable to load products");
        }

        const products = await response.json();

        // Find clicked product
        const product = products.find(
            p => Number(p.id) === Number(id)
        );

        if (!product) {
            alert("Product not found! ❌");
            return;
        }

        console.log("Selected product:", product);

        // Get cart
        let cart =
            JSON.parse(
                localStorage.getItem("luluMartCart")
            ) || [];

        // Check if already in cart
        const existingProduct =
            cart.find(
                p => Number(p.id) === Number(product.id)
            );

        if (existingProduct) {

            if (
                existingProduct.quantity >=
                product.quantity
            ) {

                alert("No more stock available! ❌");
                return;

            }

            existingProduct.quantity++;

        } else {

            cart.push({

    id: product.id,

    name: product.name,

    price: product.price,

    quantity: 1,

    imageUrl: product.imageUrl

});

        }

        // Save cart
        localStorage.setItem(
            "luluMartCart",
            JSON.stringify(cart)
        );

        alert(
            product.name +
            " added to cart! 🛒"
        );

    } catch (error) {

        console.error(
            "Add to cart error:",
            error
        );

        alert(
            "Unable to add product to cart ❌"
        );

    }

}

function viewCustomerOrder(orderId) {

    localStorage.setItem(
        "selectedOrderId",
        orderId
    );

    window.location.href =
        "order-details.html";
}

// ===============================
// CUSTOMER ORDER DETAILS
// ===============================

const orderDetailsContainer =
    document.getElementById("customerOrderDetails");
if (orderDetailsContainer) {

    loadCustomerOrderDetails();

}


async function loadCustomerOrderDetails() {

    try {

        const selectedOrderId =
            localStorage.getItem("selectedOrderId");


        if (!selectedOrderId) {

            orderDetailsContainer.innerHTML = `
                <div class="no-orders">

                    <h2>
                        Order not found ❌
                    </h2>

                    <a href="my-orders.html">
                        ← Back to My Orders
                    </a>

                </div>
            `;

            return;
        }


        // ===============================
        // GET ORDER FROM MYSQL
        // ===============================

        const response = await fetch(
            `http://localhost:8080/api/orders/${selectedOrderId}`
        );


        if (!response.ok) {

            throw new Error(
                "Failed to load order"
            );

        }


        const order =
            await response.json();


        console.log(
            "Selected Order:",
            order
        );


        // ===============================
        // PRODUCTS JSON
        // ===============================

        let products = [];

        if (order.products) {

            try {

                products =
                    typeof order.products === "string"
                    ? JSON.parse(order.products)
                    : order.products;

            } catch (error) {

                console.error(
                    "Products JSON error:",
                    error
                );

            }

        }


        // ===============================
        // PRODUCT HTML
        // ===============================

        let productsHTML = "";


        if (products.length === 0) {

            productsHTML = `
                <p>
                    No product details available.
                </p>
            `;

        } else {

            products.forEach(product => {

                const itemTotal =
                    Number(product.price) *
                    Number(product.quantity);


                productsHTML += `

                    <div class="order-product">

                        <div>

                            ${
                                product.imageUrl
                                ?
                                `
                                <img
                                    src="${product.imageUrl}"
                                    alt="${product.name}"
                                    width="80"
                                    height="80"
                                    style="
                                        object-fit: contain;
                                        margin-right: 15px;
                                    "
                                >
                                `
                                :
                                "🛍️"
                            }

                        </div>


                        <div>

                            <strong>
                                ${product.name}
                            </strong>

                            <p>
                                ₹${Number(product.price).toLocaleString()}
                                ×
                                ${product.quantity}
                            </p>

                        </div>


                        <strong>

                            ₹${itemTotal.toLocaleString()}

                        </strong>

                    </div>

                `;

            });

        }


        // ===============================
        // ORDER STATUS
        // ===============================

        const status =
            (order.status || "PLACED").toUpperCase();


        // ===============================
        // DISPLAY ORDER
        // ===============================

        orderDetailsContainer.innerHTML = `

            <div class="order-card">

                <div class="order-header">

                    <span class="order-id">

                        Order ID:
                        ${order.orderId}

                    </span>


                    <span class="
                        customer-order-status
                        status-${status.toLowerCase()}
                    ">

                        ${status}

                    </span>

                </div>


                <div class="order-info">

                    <h3>
                        👤 Customer Details
                    </h3>


                    <p>

                        <strong>
                            Customer:
                        </strong>

                        ${order.customerName || "N/A"}

                    </p>


                    <p>

                        <strong>
                            Phone:
                        </strong>

                        ${order.phone || "N/A"}

                    </p>


                    <p>

                        <strong>
                            Address:
                        </strong>

                        ${order.address || "N/A"}
                        <br>

                        ${order.city || ""}
                        -
                        ${order.pincode || ""}

                    </p>


                    <p>

                        <strong>
                            Payment:
                        </strong>

                        ${order.payment || "N/A"}

                    </p>


                    <p>

                        <strong>
                            Order Date:
                        </strong>

                        ${
                            order.orderDate
                            ?
                            new Date(
                                order.orderDate
                            ).toLocaleString()
                            :
                            "N/A"
                        }

                    </p>


                    <hr>


                    <h3>
                        🛍️ Products
                    </h3>


                    <div class="order-products">

                        ${productsHTML}

                    </div>


                    <hr>


                    <h2 class="order-total">

                        Total:
                        ₹${Number(order.total).toLocaleString()}

                    </h2>


                    <br>


                    <a
                        href="my-orders.html"
                        class="shop-btn">

                        ← Back to My Orders

                    </a>

                </div>

            </div>

        `;


    } catch (error) {

        console.error(
            "Order details error:",
            error
        );


        orderDetailsContainer.innerHTML = `

            <div class="no-orders">

                <h2>
                    Unable to load order ❌
                </h2>

                <p>
                    Please make sure Spring Boot is running.
                </p>


                <br>


                <a href="my-orders.html">

                    ← Back to My Orders

                </a>

            </div>

        `;

    }

}

