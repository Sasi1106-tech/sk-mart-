const API_URL = "http://localhost:8080/api/orders";


// ==========================================
// LOAD ADMIN ORDERS
// ==========================================

async function loadAdminOrders() {

    const tableBody =
        document.getElementById("adminOrdersTableBody");

    try {

        tableBody.innerHTML = `
            <tr>
                <td colspan="10" class="loading-orders">
                    Loading orders...
                </td>
            </tr>
        `;


        const response =
            await fetch(API_URL);


        if (!response.ok) {

            throw new Error(
                "Failed to load orders"
            );

        }


        const orders =
            await response.json();


        console.log(
            "Admin Orders:",
            orders
        );


        // ==========================================
        // UPDATE SUMMARY
        // ==========================================

        updateOrderSummary(orders);


        // ==========================================
        // NO ORDERS
        // ==========================================

        if (orders.length === 0) {

            tableBody.innerHTML = `
                <tr>
                    <td
                        colspan="10"
                        class="no-orders-table"
                    >
                        No orders found 😔
                    </td>
                </tr>
            `;

            return;
        }


        // ==========================================
        // DISPLAY ORDERS
        // ==========================================

        tableBody.innerHTML = "";


        orders
            .slice()
            .reverse()
            .forEach(order => {

                tableBody.innerHTML += `

                    <tr>

                        <!-- ID -->

                        <td>
                            ${order.id}
                        </td>


                        <!-- ORDER ID -->

                        <td>
                            <strong>
                                ${order.orderId}
                            </strong>
                        </td>


                        <!-- CUSTOMER -->

                        <td>
                            ${order.customerName || "N/A"}
                        </td>


                        <!-- PHONE -->

                        <td>
                            ${order.phone || "N/A"}
                        </td>


                        <!-- ADDRESS -->

                        <td>

                            ${order.address || "N/A"}

                            <br>

                            ${order.city || ""}

                            -

                            ${order.pincode || ""}

                        </td>


                        <!-- PAYMENT -->

                        <td>
                            ${order.payment || "N/A"}
                        </td>


                        <!-- TOTAL -->

                        <td>

                            ₹${Number(
                                order.total || 0
                            ).toLocaleString()}

                        </td>


                        <!-- DATE -->

                        <td>

                            ${
                                order.orderDate
                                ? new Date(
                                    order.orderDate
                                  ).toLocaleString()
                                : "N/A"
                            }

                        </td>


                        <!-- STATUS -->

                        <td>

                            <span
                                class="admin-status status-${(
                                    order.status ||
                                    "PLACED"
                                ).toLowerCase()}"
                            >

                                ${
                                    order.status ||
                                    "PLACED"
                                }

                            </span>

                        </td>


                        <!-- ACTION -->

                        <td>

                            <select
                                class="status-select"
                                onchange="
                                    updateOrderStatus(
                                        ${order.id},
                                        this.value
                                    )
                                "
                            >

                                <option
                                    value="PLACED"
                                    ${
                                        order.status === "PLACED"
                                        ? "selected"
                                        : ""
                                    }
                                >
                                    PLACED
                                </option>


                                <option
                                    value="PACKED"
                                    ${
                                        order.status === "PACKED"
                                        ? "selected"
                                        : ""
                                    }
                                >
                                    PACKED
                                </option>


                                <option
                                    value="SHIPPED"
                                    ${
                                        order.status === "SHIPPED"
                                        ? "selected"
                                        : ""
                                    }
                                >
                                    SHIPPED
                                </option>


                                <option
                                    value="DELIVERED"
                                    ${
                                        order.status === "DELIVERED"
                                        ? "selected"
                                        : ""
                                    }
                                >
                                    DELIVERED
                                </option>


                                <option
                                    value="CANCELLED"
                                    ${
                                        order.status === "CANCELLED"
                                        ? "selected"
                                        : ""
                                    }
                                >
                                    CANCELLED
                                </option>

                            </select>

                            <button
    class="view-order-btn"
    onclick="viewOrder(${order.id})">

    👁️ View

</button>

                        </td>

                    </tr>

                `;

            });


    } catch (error) {

        console.error(
            "Load admin orders error:",
            error
        );


        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="10"
                    class="error-orders"
                >

                    Unable to load orders ❌

                    <br>

                    Make sure Spring Boot is running.

                </td>

            </tr>

        `;

    }

}


// ==========================================
// UPDATE ORDER SUMMARY
// ==========================================

function updateOrderSummary(orders) {

    const totalOrders =
        document.getElementById(
            "adminTotalOrders"
        );

    const placedOrders =
        document.getElementById(
            "placedOrders"
        );

    const shippedOrders =
        document.getElementById(
            "shippedOrders"
        );

    const totalSales =
        document.getElementById(
            "adminTotalSales"
        );


    // Total orders

    totalOrders.innerText =
        orders.length;


    // Placed

    const placed =
        orders.filter(
            order =>
                (order.status || "PLACED")
                .toUpperCase() === "PLACED"
        ).length;


    placedOrders.innerText =
        placed;


    // Shipped

    const shipped =
        orders.filter(
            order =>
                (order.status || "")
                .toUpperCase() === "SHIPPED"
        ).length;


    shippedOrders.innerText =
        shipped;


    // Total sales

    const sales =
        orders.reduce(
            (sum, order) =>
                sum + Number(order.total || 0),
            0
        );


    totalSales.innerText =
        "₹" + sales.toLocaleString();

}


// ==========================================
// UPDATE ORDER STATUS
// ==========================================

async function updateOrderStatus(
    orderId,
    newStatus
) {

    try {

        console.log(
            "Updating order:",
            orderId,
            "Status:",
            newStatus
        );


        const response =
            await fetch(
                `${API_URL}/${orderId}/status?status=${newStatus}`,
                {
                    method: "PUT"
                }
            );


        if (!response.ok) {

            throw new Error(
                "Failed to update order status"
            );

        }


        const updatedOrder =
            await response.json();


        console.log(
            "Updated order:",
            updatedOrder
        );


        alert(
            "Order status updated successfully! ✅"
        );


        // Reload orders

        loadAdminOrders();


    } catch (error) {

        console.error(
            "Update status error:",
            error
        );


        alert(
            "Unable to update order status ❌"
        );


        // Reload original data

        loadAdminOrders();

    }

}


// ==========================================
// ADMIN LOGOUT
// ==========================================

function adminLogout() {

    localStorage.removeItem(
        "luluMartAdminLoggedIn"
    );


    alert(
        "Admin logged out successfully! 👋"
    );


    window.location.href =
        "index.html";

}


// ==========================================
// LOAD ORDERS WHEN PAGE OPENS
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadAdminOrders();

    }
);

// ==========================================
// VIEW ORDER DETAILS
// ==========================================

async function viewOrder(orderId) {

    const modal =
        document.getElementById("orderDetailsModal");

    const content =
        document.getElementById("orderDetailsContent");

    try {

        // Show modal
        modal.style.display = "flex";

        content.innerHTML = `
            <p>Loading order details... ⏳</p>
        `;

        // Get all orders
        const response =
            await fetch(API_URL);

        if (!response.ok) {

            throw new Error(
                "Failed to load order"
            );

        }

        const orders =
            await response.json();

        // Find selected order
        const order =
            orders.find(
                item =>
                    Number(item.id) ===
                    Number(orderId)
            );

        if (!order) {

            content.innerHTML = `
                <p>
                    Order not found ❌
                </p>
            `;

            return;
        }

        const status =
            (
                order.status ||
                "PLACED"
            ).toUpperCase();

        // Display order
        content.innerHTML = `

            <div class="order-detail-item">

                <strong>
                    Order ID
                </strong>

                <span>
                    ${order.orderId}
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Customer
                </strong>

                <span>
                    ${order.customerName || "N/A"}
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Phone
                </strong>

                <span>
                    ${order.phone || "N/A"}
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Address
                </strong>

                <span>
                    ${order.address || "N/A"}
                    <br>
                    ${order.city || ""}
                    -
                    ${order.pincode || ""}
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Payment
                </strong>

                <span>
                    ${order.payment || "N/A"}
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Order Date
                </strong>

                <span>
                    ${
                        order.orderDate
                        ? new Date(
                            order.orderDate
                          ).toLocaleString()
                        : "N/A"
                    }
                </span>

            </div>


            <div class="order-detail-item">

                <strong>
                    Status
                </strong>

                <span
                    class="admin-status status-${status.toLowerCase()}"
                >
                    ${status}
                </span>

            </div>


            <div class="order-detail-total">

                Total:

                ₹${Number(
                    order.total || 0
                ).toLocaleString()}

            </div>

        `;

    } catch (error) {

        console.error(
            "View order error:",
            error
        );

        content.innerHTML = `
            <p>
                Unable to load order details ❌
            </p>
        `;

    }

}


// ==========================================
// CLOSE ORDER MODAL
// ==========================================

function closeOrderModal() {

    const modal =
        document.getElementById(
            "orderDetailsModal"
        );

    modal.style.display = "none";

}