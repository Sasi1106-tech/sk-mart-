package com.skmart.skmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
