package com.skmart.skmart.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skmart.skmart.entity.Order;
import com.skmart.skmart.entity.Product;
import com.skmart.skmart.repository.OrderRepository;
import com.skmart.skmart.repository.ProductRepository;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrderController {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public OrderController(
            OrderRepository orderRepository,
            ProductRepository productRepository) {

        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    // ==========================================
    // GET ALL ORDERS
    // ==========================================

    @GetMapping
    public List<Order> getAllOrders() {

        return orderRepository.findAll();
    }

    // ==========================================
    // GET RECENT 5 ORDERS
    // ==========================================

    @GetMapping("/recent")
    public List<Order> getRecentOrders() {

        return orderRepository.findTop5ByOrderByOrderDateDesc();
    }

    // ==========================================
    // GET ORDER BY ID
    // ==========================================

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable Long id) {

        return orderRepository.findById(id)
                .orElseThrow(
                        () -> new RuntimeException("Order not found")
                );
    }

    // ==========================================
    // PLACE NEW ORDER + UPDATE STOCK
    // ==========================================

    @PostMapping
    @Transactional
    public Order placeOrder(@RequestBody Order order) {

        // ------------------------------------------
        // Basic order details
        // ------------------------------------------

        order.setOrderDate(LocalDateTime.now());

        // Generate Order ID
        if (order.getOrderId() == null ||
                order.getOrderId().isEmpty()) {

            order.setOrderId(
                    "LM" + System.currentTimeMillis()
            );
        }

        // Default status
        if (order.getStatus() == null ||
                order.getStatus().isEmpty()) {

            order.setStatus("PLACED");
        }

        // ------------------------------------------
        // Validate products
        // ------------------------------------------

        if (order.getProducts() == null ||
                order.getProducts().isBlank()) {

            throw new RuntimeException(
                    "Order must contain products"
            );
        }

        try {

            JsonNode products =
                    new ObjectMapper().readTree(
                            order.getProducts()
                    );

            // ------------------------------------------
            // CHECK STOCK FIRST
            // ------------------------------------------

            for (JsonNode item : products) {

                if (!item.has("id") ||
                        !item.has("quantity")) {

                    throw new RuntimeException(
                            "Invalid product information in order"
                    );
                }

                Long productId =
                        item.get("id").asLong();

                int requestedQuantity =
                        item.get("quantity").asInt();

                if (requestedQuantity <= 0) {

                    throw new RuntimeException(
                            "Invalid product quantity"
                    );
                }

                Product product =
                        productRepository.findById(productId)
                                .orElseThrow(
                                        () -> new RuntimeException(
                                                "Product not found: "
                                                        + productId
                                        )
                                );

                // Check available stock
                if (product.getQuantity()
                        < requestedQuantity) {

                   throw new ResponseStatusException(
    HttpStatus.BAD_REQUEST,
    "Insufficient stock for product: " + product.getName()
        + ". Available: " + product.getQuantity()
        + ", Requested: " + requestedQuantity
);
                }
            }

            // ------------------------------------------
            // REDUCE STOCK
            // ------------------------------------------

            for (JsonNode item : products) {

                Long productId =
                        item.get("id").asLong();

                int requestedQuantity =
                        item.get("quantity").asInt();

                Product product =
                        productRepository.findById(productId)
                                .orElseThrow(
                                        () -> new RuntimeException(
                                                "Product not found: "
                                                        + productId
                                        )
                                );

                int newStock =
                        product.getQuantity()
                                - requestedQuantity;

                product.setQuantity(newStock);

                productRepository.save(product);
            }

            // ------------------------------------------
            // SAVE ORDER
            // ------------------------------------------

            return orderRepository.save(order);

        } catch (RuntimeException e) {

            throw e;

        } catch (Exception e) {

            throw new RuntimeException(
                    "Invalid products JSON",
                    e
            );
        }
    }

    // ==========================================
    // UPDATE ORDER STATUS
    // + RESTORE STOCK WHEN CANCELLED
    // ==========================================

    @PutMapping("/{id}/status")
    @Transactional
    public Order updateOrderStatus(
            @PathVariable Long id,
            @RequestParam String status) {

        // ------------------------------------------
        // Find order
        // ------------------------------------------

        Order order =
                orderRepository.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Order not found"
                                )
                        );

        String oldStatus = order.getStatus();
        String newStatus = status.toUpperCase();

        // ------------------------------------------
        // Prevent changing a cancelled order again
        // ------------------------------------------

        if ("CANCELLED".equalsIgnoreCase(oldStatus) &&
                !"CANCELLED".equals(newStatus)) {

            throw new RuntimeException(
                    "Cancelled order cannot be changed"
            );
        }

        // ------------------------------------------
        // RESTORE STOCK WHEN ORDER IS CANCELLED
        // ------------------------------------------

        if (!"CANCELLED".equalsIgnoreCase(oldStatus) &&
                "CANCELLED".equals(newStatus)) {

            if (order.getProducts() == null ||
                    order.getProducts().isBlank()) {

                throw new RuntimeException(
                        "Order products information is missing"
                );
            }

            try {

                JsonNode products =
                        new ObjectMapper().readTree(
                                order.getProducts()
                        );

                // Restore stock
                for (JsonNode item : products) {

                    if (!item.has("id") ||
                            !item.has("quantity")) {

                        throw new RuntimeException(
                                "Invalid product information in order"
                        );
                    }

                    Long productId =
                            item.get("id").asLong();

                    int orderQuantity =
                            item.get("quantity").asInt();

                    Product product =
                            productRepository.findById(productId)
                                    .orElseThrow(
                                            () -> new RuntimeException(
                                                    "Product not found: "
                                                            + productId
                                            )
                                    );

                    int restoredStock =
                            product.getQuantity()
                                    + orderQuantity;

                    product.setQuantity(restoredStock);

                    productRepository.save(product);
                }

            } catch (RuntimeException e) {

                throw e;

            } catch (Exception e) {

                throw new RuntimeException(
                        "Invalid products JSON",
                        e
                );
            }
        }

        // ------------------------------------------
        // Update status
        // ------------------------------------------

        order.setStatus(newStatus);

        return orderRepository.save(order);
    }

    // ==========================================
    // DELETE ORDER
    // ==========================================

    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable Long id) {

        Order order =
                orderRepository.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Order not found"
                                )
                        );

        orderRepository.delete(order);

        return "Order deleted successfully";
    }
}