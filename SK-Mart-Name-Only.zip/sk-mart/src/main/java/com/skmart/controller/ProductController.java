package com.skmart.skmart.controller;

import com.skmart.skmart.entity.Product;
import com.skmart.skmart.repository.ProductRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // ===============================
    // GET ALL PRODUCTS
    // ===============================

    @GetMapping
    public List<Product> getAllProducts() {

        return productRepository.findAll();

    }


    // ===============================
    // GET PRODUCT BY ID
    // ===============================

    @GetMapping("/{id}")
    public Product getProductById(
            @PathVariable Long id) {

        return productRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Product not found"));

    }


    // ===============================
    // ADD PRODUCT
    // ===============================

    @PostMapping
    public Product addProduct(
            @RequestBody Product product) {

        return productRepository.save(product);

    }


    // ===============================
    // UPDATE PRODUCT
    // ===============================

    @PutMapping("/{id}")
    public Product updateProduct(
            @PathVariable Long id,
            @RequestBody Product productDetails) {

        Product product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Product not found"));

        // Update name
        product.setName(
                productDetails.getName());

        // Update price
        product.setPrice(
                productDetails.getPrice());

        // Update quantity
        product.setQuantity(
                productDetails.getQuantity());

        // Update category
        product.setCategory(
                productDetails.getCategory());

        // Update image URL
        product.setImageUrl(
                productDetails.getImageUrl());

        return productRepository.save(product);

    }


    // ===============================
    // DELETE PRODUCT
    // ===============================

    @DeleteMapping("/{id}")
    public String deleteProduct(
            @PathVariable Long id) {

        Product product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Product not found"));

        productRepository.delete(product);

        return "Product deleted successfully";

    }

}