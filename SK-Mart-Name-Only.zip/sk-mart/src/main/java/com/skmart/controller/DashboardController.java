package com.skmart.skmart.controller;

import com.skmart.skmart.repository.OrderRepository;
import com.skmart.skmart.repository.ProductRepository;
import com.skmart.skmart.repository.UserRepository;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    public DashboardController(
            ProductRepository productRepository,
            OrderRepository orderRepository,
            UserRepository userRepository) {

        this.productRepository = productRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/stats")
    public Map<String, Object> getDashboardStats() {

        Map<String, Object> stats = new HashMap<>();

        long totalProducts =
                productRepository.count();

        long totalOrders =
                orderRepository.count();

        long totalUsers =
                userRepository.count();

        double totalSales =
                orderRepository.findAll()
                        .stream()
                        .mapToDouble(order -> order.getTotal())
                        .sum();

        stats.put("totalProducts", totalProducts);
        stats.put("totalOrders", totalOrders);
        stats.put("totalUsers", totalUsers);
        stats.put("totalSales", totalSales);

        return stats;
    }
}