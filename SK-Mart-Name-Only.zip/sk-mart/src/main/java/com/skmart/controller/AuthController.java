package com.skmart.skmart.controller;

import com.skmart.skmart.entity.User;
import com.skmart.skmart.repository.UserRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody User user) {

        Map<String, Object> response = new HashMap<>();

        if (userRepository.existsByEmail(user.getEmail())) {

            response.put("success", false);
            response.put("message", "Email already registered");

            return response;
        }

        user.setPassword(
                passwordEncoder.encode(user.getPassword())
        );

        User savedUser = userRepository.save(user);

        response.put("success", true);
        response.put("message", "Account created successfully");
        response.put("userId", savedUser.getId());
        response.put("name", savedUser.getName());
        response.put("email", savedUser.getEmail());

        return response;
    }

    @PostMapping("/login")
    public Map<String, Object> login(
            @RequestBody User loginUser) {

        Map<String, Object> response = new HashMap<>();

        User user = userRepository
                .findByEmail(loginUser.getEmail())
                .orElse(null);

        if (user == null ||
                !passwordEncoder.matches(
                        loginUser.getPassword(),
                        user.getPassword())) {

            response.put("success", false);
            response.put("message", "Invalid email or password");

            return response;
        }

        response.put("success", true);
        response.put("message", "Login successful");
        response.put("userId", user.getId());
        response.put("name", user.getName());
        response.put("email", user.getEmail());

        return response;
    }
}