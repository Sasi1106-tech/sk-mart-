package com.skmart.skmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkMartApplication.class, args);
	}

}
