package com.skmart.skmart;

import com.skmart.skmart.entity.Product;
import com.skmart.skmart.repository.ProductRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner loadProducts(ProductRepository productRepository) {

        return args -> {

           addProduct(productRepository, "Laptop", 55000, 10,
        "Electronics", "/images/laptop.jpg");

addProduct(productRepository, "Smartphone", 25000, 15,
        "Electronics", "/images/mobile.jpg");

addProduct(productRepository, "Wireless Earbuds", 2499, 25,
        "Electronics", "/images/headphones.jpg");

addProduct(productRepository, "Bluetooth Speaker", 3499, 20,
        "Electronics", "/images/speaker.jpg");

addProduct(productRepository, "Oversized T-Shirt", 799, 30,
        "Fashion", "");

addProduct(productRepository, "Casual Shirt", 1299, 20,
        "Fashion", "");

addProduct(productRepository, "Denim Jeans", 1999, 15,
        "Fashion", "");

addProduct(productRepository, "Hoodie", 1499, 18,
        "Fashion", "");

addProduct(productRepository, "Table Lamp", 899, 20,
        "Home", "");

addProduct(productRepository, "Water Bottle", 499, 35,
        "Home", "");

addProduct(productRepository, "Bedsheet Set", 1299, 15,
        "Home", "");

addProduct(productRepository, "Storage Box", 699, 25,
        "Home", "");

addProduct(productRepository, "Smart Watch", 3999, 15,
        "Accessories", "/images/smartwatch.jpg");

addProduct(productRepository, "Laptop Backpack", 1299, 20,
        "Accessories", "/images/laptop.jpg");

addProduct(productRepository, "Phone Stand", 399, 30,
        "Accessories", "/images/mobile.jpg");

addProduct(productRepository, "USB-C Cable", 299, 40,
        "Accessories", "/images/usb-cable.jpg");
            System.out.println("=================================");
            System.out.println("Product initialization completed!");
            System.out.println("=================================");
        };
    }

    private void addProduct(
        ProductRepository repository,
        String name,
        double price,
        int quantity,
        String category,
        String imageUrl) {

    var existingProduct = repository.findByName(name);

    if (existingProduct.isPresent()) {

        Product product = existingProduct.get();

        // Update image if it is available
        if (imageUrl != null && !imageUrl.isEmpty()) {
            product.setImageUrl(imageUrl);
            repository.save(product);
            System.out.println("Image updated: " + name);
        } else {
            System.out.println("Already exists: " + name);
        }

        return;
    }

    Product product = new Product(
            name,
            price,
            quantity,
            category
    );

    product.setImageUrl(imageUrl);

    repository.save(product);

    System.out.println("Added: " + name);
}
}